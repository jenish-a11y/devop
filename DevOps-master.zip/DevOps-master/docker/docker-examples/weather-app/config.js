apiKey = '410bba55acb8ca522a483eb47758c68f';
url = `http://api.openweathermap.org/data/2.5/weather?appid=${apiKey}&units=imperial`

module.exports = {
  'url': url
}
