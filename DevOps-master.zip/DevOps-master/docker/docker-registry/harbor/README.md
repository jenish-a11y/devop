# Setting up Harbor Registry

Vagrantfile to spinup machine for setting up Harbor Docker registry

Documentations can be found at DevOps repo.