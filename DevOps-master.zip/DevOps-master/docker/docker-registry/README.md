# Setting up Docker Registry

Vagrantfile to spinup machine for setting up local Docker registry
