#!/bin/bash

echo "This is a $season"
