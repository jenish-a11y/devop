#!/bin/bash

myskills=DevOps

echo "I have learned $myskills over the period"
echo '$myskills is the most demanding skills'
