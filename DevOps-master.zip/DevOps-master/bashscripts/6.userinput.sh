#!/bin/bash

read -p "Username "  myname
read -sp "Password "  mypass

echo "Hello $myname, Welcome to this system."
