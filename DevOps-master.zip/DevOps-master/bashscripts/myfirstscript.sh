#!/bin/bash

#This script is for demo purpose only.
echo "#############################"
echo "The current date and time is"
echo ""
date
echo "#############################"
echo "The disks utilization is."
df -h
echo ""
echo "#############################"
echo "The memory utilization is."
free -m
echo
echo "#############################"
echo "Good morning, DevOps"

