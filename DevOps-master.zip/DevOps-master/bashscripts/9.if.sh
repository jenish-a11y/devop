#!/bin/bash

A=10

if [ $A == 5 ];
then
	echo "The number is 5"
elif [ $A == 10 ];
then
	echo "The number is 10"
else
	echo "The number is unknown"
fi
