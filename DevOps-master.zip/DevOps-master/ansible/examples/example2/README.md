# Practice lab for http webserver setp.
# Install apache2 package with ad-hoc command
# copy module