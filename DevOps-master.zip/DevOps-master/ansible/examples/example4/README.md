# Ansible modules, finding suitable module.
# This playbook tasks to add a user into the database and create a database, give privilege to the user.