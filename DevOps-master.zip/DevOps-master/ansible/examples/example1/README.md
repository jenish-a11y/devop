# Writing inventory file
## Creating host inventory
## Managing host inventory with group
## Group of groups
## Defining variables

Simple command to run tasks using inventory
`$ ansible -i inventory -m ping all`