# Writing playbook
# playbook syntax, plays, tasks, modules
# This playbook contains http webserver setup and mysql installation in ubuntu server, deploy sample index.html file.